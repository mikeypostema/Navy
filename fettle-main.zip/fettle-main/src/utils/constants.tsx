export const Status = {
    OPERATIONAL: "operational",
    PARTIAL_OUTAGE: "partial_outage",
    OUTAGE: "outage",
    UNKNOWN: "unknown"
}
