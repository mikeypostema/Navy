interface ServiceStatus {
    name: string;
    status: string;
    date?: string;    
}

export default ServiceStatus;