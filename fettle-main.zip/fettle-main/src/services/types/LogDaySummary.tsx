interface LogDaySummary {
    avg_response_time: number;
    current_status: string;
    date: string;
    status: string;
}

export default LogDaySummary;