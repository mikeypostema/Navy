interface SystemStatus {
    title: string;
    status: string;
    datetime?: string;    
}

export default SystemStatus;