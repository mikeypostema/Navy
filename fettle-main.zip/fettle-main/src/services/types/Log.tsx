interface Log {
    id: string;
    response_time: string;
    status: string;
    created_at: string;
}

export default Log;